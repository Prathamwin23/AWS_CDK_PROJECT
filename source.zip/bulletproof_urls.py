from django.contrib import admin
from django.urls import path, include
from django.http import JsonResponse

def health_check(request):
    return JsonResponse({'status': 'healthy'})

# Import the view directly to avoid module issues
try:
    from Class_Based_Viewsapp.views import Allcompanies
    home_view = Allcompanies.as_view()
except ImportError:
    from django.http import HttpResponse
    def home_view(request):
        return HttpResponse("Django is running!")

urlpatterns = [
    path('', home_view, name='home'),
    path('company/', include('Class_Based_Viewsapp.urls')),
    path('health/', health_check, name='health'),
    path('admin/', admin.site.urls),
]