from django.contrib import admin
from Class_Based_Viewsapp.models import Comapny,Product

# Register your models here.
admin.site.register(Comapny)
admin.site.register(Product)
