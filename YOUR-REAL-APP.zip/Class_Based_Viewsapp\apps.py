from django.apps import AppConfig


class ClassBasedViewsappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Class_Based_Viewsapp'
